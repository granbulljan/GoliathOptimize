All credit for the terrain textures goes to user Yughues on Unity Asset Store. Thank you!
