#include "RenderTexture.h"
GLint RenderTexture::_last_width = 0;
GLint RenderTexture::_last_height = 0;