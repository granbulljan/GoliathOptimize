#include "Application.h"
int main(int argc, const char *argv[]) {
	Application application;
	application.initialize();
	application.run();
}